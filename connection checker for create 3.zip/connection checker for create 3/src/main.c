#include <kipr/wombat.h>

int main()
{
    printf("Hello World\n");
    create3_connect();
    return 0;
}
